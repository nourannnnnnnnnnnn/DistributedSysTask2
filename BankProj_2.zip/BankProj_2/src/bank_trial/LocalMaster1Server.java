/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author noran
 */
public class LocalMaster1Server {

    public SheroukCityIMP sheroukCityData;
    public NasrCityIMP nasrCityData;
    public NewCairoCityIMP newcairoCityData;

    public LocalMaster1Server() throws RemoteException {
        sheroukCityData = new SheroukCityIMP();
        nasrCityData = new NasrCityIMP();
        newcairoCityData = new NewCairoCityIMP();
    }

    // Method to add a client to Sherouk City
//    public void addClientToSheroukCity(Client client) {
//        sheroukCityData.addClient(client);
//        
//          System.out.println("Client added successfully to Sherouk City:");
//  
//        
//        
//    }
//         public void addClientToNasrkCity(Client client) {
//         nasrCityData.addClient(client);
//        
//          System.out.println("Client added successfully to Nasr City:");
//  
//        
//        
//    }
//    
//           public void addClientToNewCairoCity(Client client) {
//         nasrCityData.addClient(client);
//        
//          System.out.println("Client added successfully to Nasr City:");
//  
//        
//        
//    }
    public static void main(String[] args) {

        try {

            // Create an instance of the remote class
            LocalMaster1IMP localMaster = new LocalMaster1IMP();

            // Get the RMI registry on port 1099 (default port)
            Registry registry = LocateRegistry.createRegistry(1099);

            // Bind the remote object to a name in the registry
            registry.bind("LocalMaster1", localMaster);
            localMaster.server_form.setVisible(true);

            System.out.println("LocalMaster1 server is running.....");

        } catch (Exception e) {
            System.err.println("LocalMaster1 server exception: " + e.toString());
            e.printStackTrace();
        }
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package bank_trial;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author noran
 */
public interface LocalMaster2 extends Remote {

    public ArrayList<Client> clients = new ArrayList<>();

    void deposit(Client client, double amount, String region) throws RemoteException;

    void Withdraw(Client c, double amount, String region, double cash) throws RemoteException;

    double Check_balance(Client c, double amount, String region) throws RemoteException;
    public ArrayList<Client> gounaCityClients = new ArrayList<>();
    public ArrayList<Client> sharmelsheikhCityClients = new ArrayList<>();
    public ArrayList<Client> hurghadaCityClients = new ArrayList<>();

    ArrayList<Client> update() throws RemoteException;

}

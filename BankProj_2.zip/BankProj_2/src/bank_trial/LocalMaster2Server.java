/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import bank_trial.NasrCityIMP;
import bank_trial.NewCairoCityIMP;
import bank_trial.SheroukCityIMP;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author noran
 */
public class LocalMaster2Server {

    public GounaIMP gounaCityData;
    public HurghadaIMP hurghadaCityData;
    public SharmElsheikhIMP sharmelsheikhCityData;
    //public NewCairoCityIMP newcairoCityData;

    public LocalMaster2Server() throws RemoteException {
        gounaCityData = new GounaIMP();
        hurghadaCityData = new HurghadaIMP();
        sharmelsheikhCityData = new SharmElsheikhIMP();
        // newcairoCityData=new NewCairoCityIMP();
    }

//    
//        public void addClientToGounaCity(Client client) {
//        gounaCityData.addClient(client);
//        
//          System.out.println("Client added successfully to Gouna City:");
//  
//        
//        
//    }
//        
//               public void addClientToHurghadaCity(Client client) {
//        gounaCityData.addClient(client);
//        
//          System.out.println("Client added successfully to Gouna City:");
//  
//        
//        
//    }
//        
//               public void addClientToSharmElsheikhCity(Client client) {
//        gounaCityData.addClient(client);
//        
//          System.out.println("Client added successfully to Gouna City:");
//  
//        
//        
//    }
    public static void main(String[] args) {

        try {

            // Create an instance of the remote class
            LocalMaster2IMP localMasterr = new LocalMaster2IMP();

            // Get the RMI registry on port 1099 (default port)
            Registry registry = LocateRegistry.createRegistry(2000);

            // Bind the remote object to a name in the registry
            registry.bind("LocalMaster2", localMasterr);
            localMasterr.server_form.setVisible(true);

            System.out.println("LocalMaster2 server is running.....");

        } catch (Exception e) {
            System.err.println("LocalMaster2 server exception: " + e.toString());
            e.printStackTrace();
        }
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author noran
 */
public class NewCairoCityServer {

    public static void main(String[] args) {
        try {

            NewCairoCityIMP newcairoCityImpl = new NewCairoCityIMP();

            Registry registry = LocateRegistry.createRegistry(1095);

            registry.bind("NewCairoCity", newcairoCityImpl);

            System.out.println("SheroukCity server is running...");
        } catch (Exception e) {
            System.err.println("SheroukCity server exception: " + e.toString());
            e.printStackTrace();
        }
    }

}

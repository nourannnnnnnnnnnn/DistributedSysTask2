/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author noran
 */
public class NewCairoCityIMP extends UnicastRemoteObject implements NewCairoCity {

    public ArrayList<Client> newcairoCityClients = new ArrayList<>();

    public NewCairoCityIMP() throws RemoteException {
        super();
        // Hardcode initial clients for SheroukCity
        newcairoCityClients.add(new Client(400.0, "Sherif", "5"));
        newcairoCityClients.add(new Client(450.0, "Karim", "6"));
    }

//    public void addClient(Client client) {
//        clients.add(client);
//    }
    @Override
    public void deposite(Client c, double amount) throws RemoteException {

        double newbalance = c.getBalance() + amount; // kda di operation
        c.setBalance(newbalance); //hayl2ay updated balance

    }

    @Override
    public double withdraw(double cash, double amount, Client c) throws RemoteException {
        double newbalance = c.getBalance() + amount;

        if (cash > newbalance) {
            System.out.println("You don't have enough money");
        } else {
            newbalance -= cash;
        }
        return newbalance;
    }

    public double Check_balance(Client c, double amount, String region) throws RemoteException {
        double res = c.getBalance();
        return res;

    }

}

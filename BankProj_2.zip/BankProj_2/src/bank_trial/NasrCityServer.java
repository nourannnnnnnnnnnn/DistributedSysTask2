/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author noran
 */
public class NasrCityServer {

    public static void main(String[] args) {
        try {

            NasrCityIMP nasrCityImpl = new NasrCityIMP();

            Registry registry = LocateRegistry.createRegistry(1097);

            registry.bind("NasrCity", nasrCityImpl);

            System.out.println("NasrCity server is running...");
        } catch (Exception e) {
            System.err.println("NasrCity server exception: " + e.toString());
            e.printStackTrace();
        }
    }

}

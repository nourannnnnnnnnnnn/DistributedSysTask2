/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import static bank_trial.LocalMaster1.sheroukCityClients;
import static bank_trial.LocalMaster2.sharmelsheikhCityClients;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author noran
 */
public class SharmElsheikhIMP extends UnicastRemoteObject implements SharmElsheikh {

    public ArrayList<Client> sharmelsheikhCityClients = new ArrayList<>();

    // public ArrayList<Client> clients ;
    public SharmElsheikhIMP() throws RemoteException {
        //clients = new ArrayList<>();
        super();

        sharmelsheikhCityClients.add(new Client(700.0, "Ibrahim", "11"));
        sharmelsheikhCityClients.add(new Client(750.0, "Ali", "12"));

    }

//    public void addClient(Client client) {
//        clients.add(client);
//    }
//    
//    
//    
    @Override
    public double withdraw(double cash, double amount, Client c) throws RemoteException {

        double newBalance = -1;

        for (Client client : sharmelsheikhCityClients) {
            if (client.equals(c)) {

                newBalance = client.getBalance() - cash;

                if (newBalance < 0) {
                    System.out.println("You don't have enough money.");
                    return -1;
                } else {

                    client.setBalance(newBalance);

                    return newBalance;
                }
            }
        }

        System.out.println("Client not found.");
        return -1;

    }

    @Override
    public void deposit(Client c, double amount) throws RemoteException {

        for (Client client : sharmelsheikhCityClients) {
            if (client.equals(c)) {

                double newBalance = client.getBalance() + amount;
                client.setBalance(newBalance);

            }
        }
    }

    @Override
    public double checkBalance(Client c, double amount, String region) throws RemoteException {

        for (Client client : sharmelsheikhCityClients) {
            if (client.equals(c)) {

                return client.getBalance();
            }
        }

        System.out.println("Client not found in " + region);
        return -1;

    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author noran
 */
public class SharmElsheikhServer {

    public static void main(String[] args) {
        try {

            SharmElsheikhIMP sharmelsheikhImpl = new SharmElsheikhIMP();

            Registry registry = LocateRegistry.createRegistry(1092);

            registry.bind("SharmElsheikh", sharmelsheikhImpl);

            System.out.println("SharmElsheikh server is running...");
        } catch (Exception e) {
            System.err.println("SharmElsheikh server exception: " + e.toString());
            e.printStackTrace();
        }
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author noran
 */
public class Client implements Serializable {

    public Client(String sherouk1, String string, double balance1) {
    }
    //han3ml mnha datatype of arraylist
    public ArrayList<Client> clients = new ArrayList<>();

    double balance;
    String name;
    String clientId;
    private String accountNumber;

//    public Client(String clientId, String name, double balance) {
//        this.balance = balance;
//        this.name = name;
//       this.clientId = clientId;
//        
//      
//        
//        
//    }
    public Client(double balance, String name, String clientId) {
        this.balance = balance;
        this.name = name;
        this.clientId = clientId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Client ID: " + clientId + ", Name: " + name + ", Balance: $" + balance;
    }

}

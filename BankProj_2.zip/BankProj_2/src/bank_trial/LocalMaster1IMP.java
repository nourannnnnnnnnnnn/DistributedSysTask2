/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import bank_trial.Client;
import bank_trial.NasrCity;
import bank_trial.NewCairoCity;
import bank_trial.SheroukCity;
import java.awt.List;
import java.util.ArrayList;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author noran
 */
public class LocalMaster1IMP extends UnicastRemoteObject implements LocalMaster1 {

    private double balance;
//
    public ArrayList<Client> sheroukCityClients;
    private ArrayList<Client> nasrCityClients;
    private ArrayList<Client> newCairoCityClients;
//    
    //private ArrayList<Client> clients;
    private ArrayList<Client> allClients = new ArrayList<>();

    static LocalMaster1GUI server_form = new LocalMaster1GUI();
    private double res;

    protected LocalMaster1IMP() throws RemoteException {
        // Constructor

//  
        super();
        // Initialize sheroukCityClients with hardcoded client data
        this.sheroukCityClients = getClientsFromSheroukCity();
        this.nasrCityClients = getClientsFromNasrCity();
        this.newCairoCityClients = getClientsFromNewCairoCity();

        allClients.addAll(sheroukCityClients);
    }

    public ArrayList<Client> getClientsFromSheroukCity() {

        ArrayList<Client> sheroukClients = new ArrayList<>();
        sheroukClients.add(new Client(100.0, "Nouran", "1"));
        sheroukClients.add(new Client(200.0, "Salwa", "2"));
        return sheroukClients;
    }

    public ArrayList<Client> getClientsFromNasrCity() {

        ArrayList<Client> nasrCityClients = new ArrayList<>();
        nasrCityClients.add(new Client(300, "Nour", "3"));
        nasrCityClients.add(new Client(350.0, "Ahmed", "4"));
        return nasrCityClients;
    }

    public ArrayList<Client> getClientsFromNewCairoCity() {

        ArrayList<Client> newCairoCityClients = new ArrayList<>();
        nasrCityClients.add(new Client(400, "Sherif", "5"));
        nasrCityClients.add(new Client(450.0, "Karim", "6"));
        return newCairoCityClients;
    }

    // update function hatrg3 clients objects update master eltany lw w23 h t back you up
    // return arraylist
    // return type client w lma agy a5odha casting to arraylist
    // public ArrayList<Client> clients = new ArrayList<>();
//       void deposite(Client c,double amount,String region) throws RemoteException {
//    
//        switch(region){ // 3la tlata region
//        
//            case "SheroukCity":
//            // connect on SheroukCity server
//            // getRegistry portno,localhost
//            // look up 3la 2smha
//            //object of interface of sherouk city
//             // call deposite function   3la 7sb region eli ana 3aiza
//            try {
//            // Connect to SheroukCityServer
//            Registry registry = LocateRegistry.getRegistry("localhost", 1097); // Assuming SheroukCityServer is running on localhost and port 1097
//            
//            // Look up SheroukCity interface
//            SheroukCity sheroukCity = (SheroukCity) registry.lookup("SheroukCity");
//            
//            // Now you have the SheroukCity interface object, you can call the deposit function
//             sheroukCity.deposite(c, amount);
//            
//            // Optionally, handle any RemoteException that might occur
//            
//        } catch (Exception e) {
//            // Handle exceptions
//            e.printStackTrace();
//        }
//                
//                
//    
//                
//        
//                
//        }
//    
//           
//           
    public void Withdraw(Client c, double amount, String region, double cash) throws RemoteException {

        // 3la tlata region
        // connect on SheroukCity server
        // getRegistry portno,localhost
        // look up 3la 2smha
        //object of interface of sherouk city
        // call deposite function   3la 7sb region eli ana 3aiza
        switch (region) { // 3la tlata region

            case "SheroukCity":
                try {

                    Registry registry = LocateRegistry.getRegistry("localhost", 1097);
                    SheroukCity sheroukCity = (SheroukCity) registry.lookup("SheroukCity");
                    sheroukCity.withdraw(cash, amount, c);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "NasrCity":
                try {

                    Registry registry = LocateRegistry.getRegistry("localhost", 1096);
                    NasrCity nasrCity = (NasrCity) registry.lookup("NasrCity");
                    nasrCity.withdraw(cash, amount, c);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "NewCairoCity":
                try {

                    Registry registry = LocateRegistry.getRegistry("localhost", 1095);
                    NewCairoCity newCairoCity = (NewCairoCity) registry.lookup("NewCairoCity");
                    newCairoCity.withdraw(cash, amount, c);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            default:
                System.out.println("Invalid region specified.");
                break;
        }

    }

    @Override

    public double Check_balance(Client c, double amount, String region) throws RemoteException {
        double res = 0;

        switch (region) {
            case "SheroukCity":
                try {

                    Registry registry = LocateRegistry.getRegistry("localhost", 1097);
                    SheroukCity sheroukCity = (SheroukCity) registry.lookup("SheroukCity");
                    res = sheroukCity.Check_balance(c, amount, region);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "NasrCity":
                try {

                    Registry registry = LocateRegistry.getRegistry("localhost", 1096);
                    NasrCity nasrCity = (NasrCity) registry.lookup("NasrCity");
                    res = nasrCity.Check_balance(c, amount, region);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "NewCairoCity":
                try {

                    Registry registry = LocateRegistry.getRegistry("localhost", 1095);
                    NewCairoCity newCairoCity = (NewCairoCity) registry.lookup("NewCairoCity");
                    res = newCairoCity.Check_balance(c, amount, region);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            default:
                System.out.println("Invalid region specified.");
                break;
        }

        return res;

    }

//      @Override
//   
//     ArrayList<Client> update(){
//        // server_form.updateTextArea(clients);
//        return clients;
//    }
//       
//       
// 
//   public void updateGUI(ArrayList<Client> clients) {
//    for (Client client : clients) {
//        server_form.updateTextArea(client.getName());
//        // Adjust the above line according to the structure of your Client class
//        // For example, if getName() is not a valid method, replace it with the appropriate method to get the client's name
//    }
    @Override
    public void deposit(Client c, double amount, String region) throws RemoteException {
        switch (region) {
            case "SheroukCity":
                try {
                    // Connect to SheroukCity server
                    Registry registry = LocateRegistry.getRegistry("localhost", 1097);
                    SheroukCity sheroukCity = (SheroukCity) registry.lookup("SheroukCity");

                    sheroukCity.deposite(c, amount);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "NasrCity":
                try {
                    // Connect to NasrCity server
                    Registry registry = LocateRegistry.getRegistry("localhost", 1098);
                    NasrCity nasrCity = (NasrCity) registry.lookup("NasrCity");
                    nasrCity.deposite(c, amount);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "NewCairoCity":
                try {

                    Registry registry = LocateRegistry.getRegistry("localhost", 1099);
                    NewCairoCity newCairoCity = (NewCairoCity) registry.lookup("NewCairoCity");
                    newCairoCity.deposite(c, amount);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            default:
                System.out.println("Invalid region specified.");
                break;
        }

    }

//     public LocalMaster1IMP(ArrayList<Client> clients) throws RemoteException {
//        this.clients = clients;
//    }
//    
    @Override
    public ArrayList<Client> update() throws RemoteException {
        ArrayList<Client> updatedClients = new ArrayList<>();

        Client client1 = new Client(100.0, "Nouran", "1");
        Client client2 = new Client(200.0, "Salwa", "2");
        Client client3 = new Client(300.0, "Nour", "3");
        Client client4 = new Client(350.0, "Ahmed", "4");
        Client client5 = new Client(400.0, "Sherif", "5");
        Client client6 = new Client(450.0, "Karim", "6");
        Client client7 = new Client(500.0, "Amr", "7");
        Client client8 = new Client(550.0, "Karma", "8");
        Client client9 = new Client(600.0, "Jana", "9");
        Client client10 = new Client(650.0, "Shahd", "10");
        Client client11 = new Client(600.0, "Ibrahim", "11");
        Client client12 = new Client(650.0, "Ali", "12");

        updatedClients.add(client1);
        updatedClients.add(client2);

        updatedClients.add(client3);
        updatedClients.add(client4);

        updatedClients.add(client5);
        updatedClients.add(client6);

        updatedClients.add(client7);
        updatedClients.add(client8);

        updatedClients.add(client9);
        updatedClients.add(client10);

        updatedClients.add(client11);
        updatedClients.add(client12);

        return updatedClients;

    }

}

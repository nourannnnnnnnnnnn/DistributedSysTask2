/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author noran
 */
public class GounaServer {

    public static void main(String[] args) {
        try {

            GounaIMP gounaCityImpl = new GounaIMP();

            Registry registry = LocateRegistry.createRegistry(1094);

            registry.bind("Gouna", gounaCityImpl);

            System.out.println("Gouna server is running...");
        } catch (Exception e) {
            System.err.println("Gouna server exception: " + e.toString());
            e.printStackTrace();
        }
    }

}

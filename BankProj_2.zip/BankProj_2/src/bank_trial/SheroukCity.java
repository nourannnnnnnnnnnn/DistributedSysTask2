/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package bank_trial;

import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 *
 * @author noran
 */
public interface SheroukCity extends Remote {

    void deposite(Client c, double amount) throws RemoteException;

    public double withdraw(double cash, double amount, Client c) throws RemoteException;

    double Check_balance(Client c, double amount, String region) throws RemoteException;

    public ArrayList<Client> clients = new ArrayList<>();
}

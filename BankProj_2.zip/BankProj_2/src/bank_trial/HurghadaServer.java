/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author noran
 */
public class HurghadaServer {

    public static void main(String[] args) {
        try {

            HurghadaIMP hurghadaImpl = new HurghadaIMP();

            Registry registry = LocateRegistry.createRegistry(1093);

            registry.bind("SheroukCity", hurghadaImpl);

            System.out.println("Hurghada server is running...");
        } catch (Exception e) {
            System.err.println("Hurghada server exception: " + e.toString());
            e.printStackTrace();
        }
    }

}

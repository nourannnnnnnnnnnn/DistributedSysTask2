/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import static bank_trial.LocalMaster1.nasrCityClients;
import static bank_trial.LocalMaster1.sheroukCityClients;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author noran
 */
public class NasrCityIMP extends UnicastRemoteObject implements NasrCity {

    public ArrayList<Client> nasrCityClients = new ArrayList<>();

    //public ArrayList<Client> clients ;
    public NasrCityIMP() throws RemoteException {
        //clients = new ArrayList<>();
        nasrCityClients.add(new Client(300.0, "Nour", "3"));
        nasrCityClients.add(new Client(350.0, "Ahmed", "4"));

    }

//    public void addClient(Client client) {
//        clients.add(client);
//    }
//    
    // deposite //withdraw //check balance
    @Override
    public void deposite(Client c, double amount) throws RemoteException {

        for (Client client : nasrCityClients) {
            if (client.equals(c)) {
                // Update the balance of the client by depositing the specified amount
                double newBalance = client.getBalance() + amount;
                client.setBalance(newBalance);
                // Optionally, you can update any GUI components or perform other actions here

            }
        }
    }

    @Override
    public double withdraw(double cash, double amount, Client c) throws RemoteException {

        double newBalance = -1;

        for (Client client : nasrCityClients) {
            if (client.equals(c)) {

                newBalance = client.getBalance() - cash;

                if (newBalance < 0) {
                    System.out.println("You don't have enough money.");
                    return -1;
                } else {

                    client.setBalance(newBalance);

                    return newBalance;
                }
            }
        }

        System.out.println("Client not found.");
        return -1;

    }

    public double Check_balance(Client c, double amount, String region) throws RemoteException {
        for (Client client : nasrCityClients) {
            if (client.equals(c)) {

                return client.getBalance();
            }
        }

        System.out.println("Client not found in " + region);
        return -1;
    }

}

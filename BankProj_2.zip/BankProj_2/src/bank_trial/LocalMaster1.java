/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package bank_trial;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
/**
 *
 * @author noran
 */
public interface LocalMaster1 extends Remote {

    public ArrayList<Client> clients = new ArrayList<>();
    //ArrayList<Client>  update() throws RemoteException;

    // public void updateGUI(ArrayList<Client> clients) throws RemoteException;
    //  public void updateGUI(ArrayList<Client> clients) throws RemoteException;
    void deposit(Client client, double amount, String region) throws RemoteException;

    void Withdraw(Client c, double amount, String region, double cash) throws RemoteException;

    double Check_balance(Client c, double amount, String region) throws RemoteException;
    public ArrayList<Client> sheroukCityClients = new ArrayList<>();
    public ArrayList<Client> nasrCityClients = new ArrayList<>();
    public ArrayList<Client> newCairoCityClients = new ArrayList<>();

    ArrayList<Client> update() throws RemoteException;

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
/**
 *
 * @author noran
 */
public class SheroukCityServer {
    public static void main(String[] args) {
        try {
            
            SheroukCityIMP sheroukCityImpl = new SheroukCityIMP();

            
            Registry registry = LocateRegistry.createRegistry(1097);

            
            registry.bind("SheroukCity", sheroukCityImpl);

        System.out.println("SheroukCity server is running...");
        } catch (Exception e) {
            System.err.println("SheroukCity server exception: " + e.toString());
            e.printStackTrace();
        }
    }

}

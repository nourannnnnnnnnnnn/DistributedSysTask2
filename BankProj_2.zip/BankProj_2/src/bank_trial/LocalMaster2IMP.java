/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank_trial;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author noran
 */
public class LocalMaster2IMP extends UnicastRemoteObject implements LocalMaster2 {

    private ArrayList<Client> clients;
    private double balance;
//
    private ArrayList<Client> gounaCityClients;
    private ArrayList<Client> hurghadaClients;
    private ArrayList<Client> sharmelelsheikhCityClients;
//    

    static LocalMaster2GUI server_form = new LocalMaster2GUI();
    private double res;

    //private ArrayList<Client> clients; //  
    public LocalMaster2IMP() throws RemoteException {
        // Constructor

        // this.clients = new ArrayList<>();
        super();
        // Initialize sheroukCityClients with hardcoded client data
        this.gounaCityClients = getClientsFromGounaCity();
        this.hurghadaClients = getClientsFromHurghadaCity();
        this.sharmelelsheikhCityClients = getClientsFromSharmElsheikhCity();
//        

    }

    public ArrayList<Client> getClientsFromGounaCity() {
        // Logic to retrieve clients from SheroukCity
        ArrayList<Client> gounaCityClients = new ArrayList<>();
        gounaCityClients.add(new Client(500.0, "Amr", "5"));
        gounaCityClients.add(new Client(550.0, "Karma", "6"));
        return gounaCityClients;
    }

    public ArrayList<Client> getClientsFromHurghadaCity() {
        // Logic to retrieve clients from SheroukCity
        ArrayList<Client> hurghadaClients = new ArrayList<>();
        hurghadaClients.add(new Client(600.0, "Jana", "7"));
        hurghadaClients.add(new Client(650.0, "Shahd", "8"));
        return hurghadaClients;
    }

    public ArrayList<Client> getClientsFromSharmElsheikhCity() {
        // Logic to retrieve clients from SheroukCity
        ArrayList<Client> sharmelelsheikhCityClients = new ArrayList<>();
        sharmelelsheikhCityClients.add(new Client(700.0, "Ibrahim", "9"));
        sharmelelsheikhCityClients.add(new Client(750.0, "Ali", "10"));
        return sharmelelsheikhCityClients;
    }

    // update function hatrg3 clients objects update master eltany lw w23 h t back you up
    // return arraylist
    // return type client w lma agy a5odha casting to arraylist
    // public ArrayList<Client> clients = new ArrayList<>();
//       void deposite(Client c,double amount,String region) throws RemoteException {
//    
//        switch(region){ // 3la tlata region
//        
//            case "SheroukCity":
//            // connect on SheroukCity server
//            // getRegistry portno,localhost
//            // look up 3la 2smha
//            //object of interface of sherouk city
//             // call deposite function   3la 7sb region eli ana 3aiza
//            try {
//            // Connect to SheroukCityServer
//            Registry registry = LocateRegistry.getRegistry("localhost", 1097); // Assuming SheroukCityServer is running on localhost and port 1097
//            
//            // Look up SheroukCity interface
//            SheroukCity sheroukCity = (SheroukCity) registry.lookup("SheroukCity");
//            
//            // Now you have the SheroukCity interface object, you can call the deposit function
//             sheroukCity.deposite(c, amount);
//            
//            // Optionally, handle any RemoteException that might occur
//            
//        } catch (Exception e) {
//            // Handle exceptions
//            e.printStackTrace();
//        }
//                
//                
//    
//                
//        
//                
//        }
//    
//           
//           
    public void Withdraw(Client c, double amount, String region, double cash) {

        // 3la tlata region
        // connect on SheroukCity server
        // getRegistry portno,localhost
        // look up 3la 2smha
        //object of interface of sherouk city
        // call deposite function   3la 7sb region eli ana 3aiza
        switch (region) { // 3la tlata region

            case "Gouna":
                try {
                   
                    Registry registry = LocateRegistry.getRegistry("localhost", 1094);
                    Gouna gouna = (Gouna) registry.lookup("Gouna");
                    gouna.withdraw(cash, amount, c);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "Hurghada":
                try {
                    
                    Registry registry = LocateRegistry.getRegistry("localhost", 1093);
                    HurghadaIMP hurghada = (HurghadaIMP) registry.lookup("Hurghada");
                    hurghada.withdraw(cash, amount, c);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "SharmElsheikh":
                try {
                 
                    Registry registry = LocateRegistry.getRegistry("localhost", 1092);
                    SharmElsheikhIMP sharmElsheikh = (SharmElsheikhIMP) registry.lookup("SharmElsheikh");
                    sharmElsheikh.withdraw(cash, amount, c);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            default:
                System.out.println("Invalid region specified.");
                break;
        }

    }

    @Override

    public double Check_balance(Client c, double amount, String region) throws RemoteException {
        double res = 0;

        switch (region) {
            case "Gouna":
                try {
                  
                    Registry registry = LocateRegistry.getRegistry("localhost", 1094);
                    Gouna gouna = (Gouna) registry.lookup("Gouna");
                    res = gouna.Check_balance(c, amount, region);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "Hurghada":
                try {
                    Registry registry = LocateRegistry.getRegistry("localhost", 1093);
                    HurghadaIMP hurghada = (HurghadaIMP) registry.lookup("Hurghada");
                    res = hurghada.Check_balance(c, amount, region);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "SharmElsheikh":
                try {
                    // Connect to NewCairoCity server
                    Registry registry = LocateRegistry.getRegistry("localhost", 1092);
                    SharmElsheikhIMP sharmelsheikh = (SharmElsheikhIMP) registry.lookup("SharmElsheikh");
                    res = sharmelsheikh.checkBalance(c, amount, region);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            default:
                System.out.println("Invalid region specified.");
                break;
        }

        return res;

    }

    @Override
    public void deposit(Client c, double amount, String region) throws RemoteException {
        switch (region) {
            case "Gouna":
                try {
                  
                    Registry registry = LocateRegistry.getRegistry("localhost", 1094);
                    Gouna gouna = (Gouna) registry.lookup("Gouna");
                    gouna.deposite(c, amount);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "Hurghada":
                try {
                  
                    Registry registry = LocateRegistry.getRegistry("localhost", 1093);
                    HurghadaIMP hurghada = (HurghadaIMP) registry.lookup("Hurghada");
                    hurghada.deposite(c, amount);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case "SharmElsheikh":
                try {
                   
                    Registry registry = LocateRegistry.getRegistry("localhost", 1099);
                    SharmElsheikhIMP sharmelsheikh = (SharmElsheikhIMP) registry.lookup("SharmElsheikh");
                    sharmelsheikh.deposit(c, amount);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            default:
                System.out.println("Invalid region specified.");
                break;
        }

    }

    public LocalMaster2IMP(ArrayList<Client> clients) throws RemoteException {
        this.clients = clients;
    }

    @Override
    public ArrayList<Client> update() throws RemoteException {

        ArrayList<Client> updatedClients = new ArrayList<>();

        Client client1 = new Client(100.0, "Nouran", "1");
        Client client2 = new Client(200.0, "Salwa", "2");
        Client client3 = new Client(300.0, "Nour", "3");
        Client client4 = new Client(350.0, "Ahmed", "4");
        Client client5 = new Client(400.0, "Sherif", "5");
        Client client6 = new Client(450.0, "Karim", "6");
        Client client7 = new Client(500.0, "Amr", "7");
        Client client8 = new Client(550.0, "Karma", "8");
        Client client9 = new Client(600.0, "Jana", "9");
        Client client10 = new Client(650.0, "Shahd", "10");
        Client client11 = new Client(600.0, "Ibrahim", "11");
        Client client12 = new Client(650.0, "Ali", "12");

        updatedClients.add(client1);
        updatedClients.add(client2);

        updatedClients.add(client3);
        updatedClients.add(client4);

        updatedClients.add(client5);
        updatedClients.add(client6);

        updatedClients.add(client7);
        updatedClients.add(client8);

        updatedClients.add(client9);
        updatedClients.add(client10);

        updatedClients.add(client11);
        updatedClients.add(client12);

        return updatedClients;

    }

}
